# -*- coding: utf-8 -*-
"""
Pure Python/NumPy replacement for obspy/taup/c_wrappers.py.

ObsPy's TauP needs three small C loops (obspy/taup/src/inner_tau_loops.c).
These are line-by-line equivalents so that obspy.taup runs where the compiled
library can't be loaded (e.g. in the browser with Pyodide).

Drop-in: exposes the same `clibtau` object with the same call signatures as the
ctypes version (arrays are filled in place, scalars passed by value).
"""
import math

import numpy as np


class _PureTauLib:
    # ------------------------------------------------------------------
    @staticmethod
    def tau_branch_calc_time_dist_inner_loop(
            ray_params, time, dist, layer, time_dist,
            max_i, max_j, max_ray_param, allow_turn):
        p = ray_params[:max_i, 0]
        top_p = layer["top_p"][:max_j]
        bot_p = layer["bot_p"][:max_j]

        # first layer j where the ray can no longer pass (p > top_p or p > bot_p)
        stop = (p[:, None] > top_p[None, :]) | (p[:, None] > bot_p[None, :])
        has_stop = stop.any(axis=1)
        j_stop = np.where(has_stop, stop.argmax(axis=1), max_j)

        # sum of time/dist over layers [0, j_stop)
        cols = np.arange(max_j)[None, :]
        below = cols < j_stop[:, None]
        time_sum = np.where(below, time[:max_i, :max_j], 0.0).sum(axis=1)
        dist_sum = np.where(below, dist[:max_i, :max_j], 0.0).sum(axis=1)

        # the layer where the ray stops may contain the turning point
        if allow_turn:
            idx = np.nonzero(j_stop < max_j)[0]
            jj = j_stop[idx]
            turn = (top_p[jj] - p[idx]) * (p[idx] - bot_p[jj]) > 0
            idx, jj = idx[turn], jj[turn]
            time_sum[idx] += time[idx, jj]
            dist_sum[idx] += dist[idx, jj]

        # rows with p > max_ray_param are left untouched (as in the C code)
        do = p <= max_ray_param
        time_dist["time"][:max_i][do] = time_sum[do]
        time_dist["dist"][:max_i][do] = dist_sum[do]

    # ------------------------------------------------------------------
    @staticmethod
    def seismic_phase_calc_time_inner_loop(
            degree, max_distance, dist, ray_param,
            search_dist_results, ray_num_results, count):
        dist = dist.tolist()
        ray_param = ray_param.tolist()
        two_pi = 2.0 * math.pi

        temp_deg = abs(degree)
        while temp_deg > 360.0:
            temp_deg -= 360.0
        if temp_deg > 180.0:
            temp_deg = 360.0 - temp_deg
        rad_dist = temp_deg * math.pi / 180.0

        r = 0

        def scan(search_dist, r):
            for ray_num in range(count - 1):
                if (search_dist == dist[ray_num + 1]
                        and (ray_num + 1) != (count - 1)):
                    continue
                elif ((dist[ray_num] - search_dist)
                      * (search_dist - dist[ray_num + 1]) >= 0):
                    if (ray_param[ray_num] == ray_param[ray_num + 1]
                            and count > 2):
                        continue
                    search_dist_results[r] = search_dist
                    ray_num_results[r] = ray_num
                    r += 1
            return r

        n = 0
        while n * two_pi + rad_dist <= max_distance:
            r = scan(n * 2 * math.pi + rad_dist, r)
            if temp_deg != 180.0:
                r = scan((n + 1) * two_pi - rad_dist, r)
            n += 1
        return r

    # ------------------------------------------------------------------
    @staticmethod
    def bullen_radial_slowness_inner_loop(layer, p, time, dist, radius, max_i):
        top_p = layer["top_p"][:max_i]
        bot_p = layer["bot_p"][:max_i]
        top_d = layer["top_depth"][:max_i]
        bot_d = layer["bot_depth"][:max_i]
        pp = p[:max_i]

        dumb = bot_d - top_d
        with np.errstate(all="ignore"):
            valid = dumb >= 1e-10  # False for NaN too, as in the C code
            B = np.log(top_p / bot_p) / np.log((radius - top_d) / (radius - bot_d))
            arg_top = np.maximum(top_p ** 2 - pp ** 2, 0.0)
            arg_bot = np.maximum(bot_p ** 2 - pp ** 2, 0.0)
            sqrt_top = np.sqrt(arg_top)
            sqrt_bot = np.sqrt(arg_bot)
            d = (np.arctan2(pp, sqrt_bot) - np.arctan2(pp, sqrt_top)) / B
            t = (sqrt_top - sqrt_bot) / B
        dist[:max_i][valid] = d[valid]
        time[:max_i][valid] = t[valid]


clibtau = _PureTauLib()
